// vite.config.js - Configuración de Vite para build
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

export default defineConfig({
  plugins: [react()],
  build: {
    lib: {
      entry: resolve(__dirname, 'src/index.js'),
      name: 'InmoBot',
      fileName: 'inmobot-widget',
      formats: ['iife'] // IIFE para uso directo con <script>
    },
    rollupOptions: {
      output: {
        // Inline todo en un solo archivo
        inlineDynamicImports: true,
        assetFileNames: 'inmobot-widget.[ext]'
      }
    },
    // Minificar para producción
    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: true // Remover console.logs en producción
      }
    }
  },
  // Para desarrollo local
  server: {
    port: 3000,
    open: true
  }
});
